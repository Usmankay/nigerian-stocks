import React, { useEffect, useRef } from "react";
import * as PIXI from "pixi.js";

const Bubble = ({ x, y, radius, text1, text2, gradientColors }) => {
  const bubbleRef = useRef(null);

  useEffect(() => {
    const app = new PIXI.Application({
      width: radius * 2,
      height: radius * 2,
      transparent: true,
    });
    bubbleRef.current.appendChild(app.view);

    // Create a radial gradient
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    canvas.width = radius * 2;
    canvas.height = radius * 2;
    const grd = ctx.createRadialGradient(
      radius,
      radius,
      0,
      radius,
      radius,
      radius
    );

    gradientColors.forEach((color, index) => {
      grd.addColorStop(index / (gradientColors.length - 1), color);
    });

    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, radius * 2, radius * 2);

    const texture = PIXI.Texture.from(canvas);
    const sprite = new PIXI.Sprite(texture);
    sprite.anchor.set(0.5);
    sprite.x = radius;
    sprite.y = radius;
    sprite.interactive = true;
    sprite.cursor = "pointer";

    // Add hover effect
    const graphics = new PIXI.Graphics();
    graphics.lineStyle(1, 0xffffff, 1);
    graphics.drawCircle(radius, radius, radius);
    graphics.visible = false;
    app.stage.addChild(graphics);

    sprite.on("mouseover", () => {
      graphics.visible = true;
    });

    sprite.on("mouseout", () => {
      graphics.visible = false;
    });

    app.stage.addChild(sprite);

    const textStyle1 = new PIXI.TextStyle({
      fill: "white",
      fontSize: 16,
      fontWeight: "bold",
    });
    const text1Element = new PIXI.Text(text1, textStyle1);
    text1Element.anchor.set(0.5);
    text1Element.x = radius;
    text1Element.y = radius - 10;
    app.stage.addChild(text1Element);

    const textStyle2 = new PIXI.TextStyle({
      fill: "white",
      fontSize: 14,
    });
    const text2Element = new PIXI.Text(text2, textStyle2);
    text2Element.anchor.set(0.5);
    text2Element.x = radius;
    text2Element.y = radius + 10;
    app.stage.addChild(text2Element);

    return () => {
      app.destroy(true, true);
    };
  }, [radius, text1, text2, gradientColors]);

  return (
    <div ref={bubbleRef} style={{ position: "absolute", left: x, top: y }} />
  );
};

const Bubbles = () => {
  const bubbles = [
    {
      x: 100,
      y: 100,
      radius: 50,
      text1: "BTC",
      text2: "+0.01%",
      gradientColors: [
        "rgba(46, 204, 113, 0)",
        "rgba(46, 204, 113, 0.15)",
        "rgba(46, 204, 113, 0.92)",
      ],
    },
    {
      x: 200,
      y: 200,
      radius: 50,
      text1: "ETH",
      text2: "+1.50%",
      gradientColors: [
        "rgba(255,99,71, 0.1)",
        "rgba(255,99,71, 0.15)",
        "rgba(255,99,71, 0.95)",
      ],
    },
  ];

  return (
    <div
      style={{
        position: "relative",
        width: "800px",
        height: "600px",
        background: "#222222",
      }}
    >
      {bubbles.map((bubble, index) => (
        <Bubble
          key={index}
          x={bubble.x}
          y={bubble.y}
          radius={bubble.radius}
          text1={bubble.text1}
          text2={bubble.text2}
          gradientColors={bubble.gradientColors}
        />
      ))}
    </div>
  );
};

export default Bubbles;
