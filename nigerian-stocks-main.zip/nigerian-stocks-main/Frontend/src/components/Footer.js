import React from "react";
import "./Footer.css";
import { useSelector } from "react-redux";
const Footer = () => {
  const colorScheme = useSelector((state) => state.Settings.colorScheme);
  return (
    <>
      <div className="flex justify-center flex-col md:flex-row bg-[#222222] py-16 px-3 md:px-0 ">
        <div className="">
          <div className="flex flex-col items-start justify-start">
            <div className=" flex items-center">
              <img
                src={
                  colorScheme.success.name === "green"
                    ? "./SBN_ICON.png"
                    : "./SBN_ICON.png"
                }
                alt="Logo"
                className="h-[50px] w-[50px] mb-4"
              />
              <h1 className="ml-2 mb-3   text-white text-xl">STOCK BUBBLES</h1>
            </div>
            <p className="text-white text-2xl  mt-3 max-w-lg font-bold">
              About Us
            </p>
            <p className="text-white text-xl  mt-3 max-w-lg font-semibold ">
              Providing free, interactive, and visually engaging insights into
              Nigerian stock market trends designed to be simple and accessible
              for everyone.
            </p>
            <p className="text-white text-xl  mt-3 max-w-lg font-semibold ">
              This platform is for informational purposes only and does not
              offer financial advice.
            </p>
            <p className="text-white text-xl  mb-1 mt-3 max-w-lg font-semibold ">
              True Herald Ltd, 900010 Abuja, Nigeira contact@stockbubbles.com.ng
            </p>
            {/* <div className="flex items-center mt-2">
            <div className="icon-container">
              <svg viewBox="0 0 300 271" width="24" height="24">
                <path d="m236 0h46l-101 115 118 156h-92.6l-72.5-94.8-83 94.8h-46l107-123-113-148h94.9l65.5 86.6zm-16.1 244h25.5l-165-218h-27.4z"></path>
              </svg>
            </div>
            <div className="icon-container">
              <svg viewBox="0 0 512 512" width="24" height="24">
                <path d="m484.689 98.231-69.417 327.37c-5.237 23.105-18.895 28.854-38.304 17.972L271.2 365.631l-51.034 49.086c-5.647 5.647-10.372 10.372-21.256 10.372l7.598-107.722L402.539 140.23c8.523-7.598-1.848-11.809-13.247-4.21L146.95 288.614 42.619 255.96c-22.694-7.086-23.104-22.695 4.723-33.579L455.423 65.166c18.893-7.085 35.427 4.209 29.266 33.065z"></path>
              </svg>
            </div>
            <div className="icon-container">
              <svg viewBox="0 0 24 24" width="24" height="24">
                <path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z"></path>
              </svg>
            </div>
            <div className="icon-container">
              <svg viewBox="0 0 24 24" width="24" height="24">
                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"></path>
              </svg>
            </div>
            <div className="icon-container">
              <svg viewBox="4 4 42 42" width="24" height="24">
                <path d="M 14 3.9902344 C 8.4886661 3.9902344 4 8.4789008 4 13.990234 L 4 35.990234 C 4 41.501568 8.4886661 45.990234 14 45.990234 L 36 45.990234 C 41.511334 45.990234 46 41.501568 46 35.990234 L 46 13.990234 C 46 8.4789008 41.511334 3.9902344 36 3.9902344 L 14 3.9902344 z M 14 5.9902344 L 36 5.9902344 C 40.430666 5.9902344 44 9.5595687 44 13.990234 L 44 35.990234 C 44 40.4209 40.430666 43.990234 36 43.990234 L 14 43.990234 C 9.5693339 43.990234 6 40.4209 6 35.990234 L 6 13.990234 C 6 9.5595687 9.5693339 5.9902344 14 5.9902344 z M 22.572266 11.892578 C 22.187855 11.867986 21.790969 11.952859 21.433594 12.162109 C 20.480594 12.721109 20.161703 13.947391 20.720703 14.900391 L 22.53125 17.990234 L 16.666016 28 L 12 28 C 10.896 28 10 28.896 10 30 C 10 31.104 10.896 32 12 32 L 27.412109 32 C 27.569109 31.237 27.473203 30.409531 27.033203 29.644531 L 27.029297 29.640625 C 26.642297 28.966625 26.105469 28.416 25.480469 28 L 21.302734 28 L 28.978516 14.898438 C 29.536516 13.945438 29.216672 12.720109 28.263672 12.162109 C 27.309672 11.604109 26.085344 11.923953 25.527344 12.876953 L 24.849609 14.033203 L 24.171875 12.876953 C 23.8225 12.281328 23.212949 11.933564 22.572266 11.892578 z M 28.310547 19.941406 L 27.484375 21.314453 C 26.572375 22.830453 26.542953 24.706859 27.376953 26.255859 L 33.673828 37.001953 C 34.045828 37.637953 34.713391 37.990234 35.400391 37.990234 C 35.743391 37.990234 36.092156 37.902797 36.410156 37.716797 C 37.363156 37.158797 37.682047 35.933469 37.123047 34.980469 L 35.376953 32 L 38 32 C 39.104 32 40 31.104 40 30 C 40 28.896 39.104 28 38 28 L 33.033203 28 L 28.310547 19.941406 z M 14.625 34.003906 C 14.068 33.987906 13.526719 34.074328 13.011719 34.236328 L 12.566406 34.994141 C 12.007406 35.946141 12.32825 37.172469 13.28125 37.730469 C 13.59925 37.917469 13.946063 38.005859 14.289062 38.005859 C 14.976062 38.005859 15.644578 37.650625 16.017578 37.015625 L 17.09375 35.179688 C 16.50875 34.496688 15.653859 34.033906 14.630859 34.003906 L 14.625 34.003906 z"></path>
              </svg>
            </div>
          </div> */}
          </div>
        </div>
        <div className="w-[5vw] invisible md:visible"></div>
        <div className=" w-full md:w-[20vw] mt-4 md:mt-14">
          <h1 className="text-white text-2xl font-bold text-center">
            Stay Connected!
          </h1>

          <div className="flex justify-center pt-8 w-full ">
            <a
              href="https://x.com/stockbubblesNG"
              className="flex hehe justify-center text-lg w-[70%]"
            >
              Follow Us On
              <svg
                viewBox="0 0 300 271"
                width="24"
                height="24"
                className="ml-2"
              >
                <path d="m236 0h46l-101 115 118 156h-92.6l-72.5-94.8-83 94.8h-46l107-123-113-148h94.9l65.5 86.6zm-16.1 244h25.5l-165-218h-27.4z"></path>
              </svg>
            </a>
          </div>
          <div className="flex justify-center pt-4 w-full">
            <a
              href="https://www.instagram.com/stockbubbles.com.ng?igsh=bGY5cndlc3QydGcy"
              className="flex hehe justify-center text-lg w-[70%]"
            >
              Follow Us On
              <svg viewBox="0 0 24 24" width="24" height="28" className="ml-2">
                <path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z"></path>
              </svg>
            </a>
          </div>
          <div className="flex justify-center pt-4 w-full">
            <a
              href="mailto:contact@stockbubbles.com.ng
"
              className="flex hehe justify-center text-lg w-[70%]"
            >
              Contact now
              <svg
                viewBox="0 0 24 24"
                width="24"
                height="28"
                className="ml-[0.8rem]"
              >
                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"></path>
              </svg>
            </a>
          </div>
        </div>
      </div>
      <div className=" bg-[#222222] pb-6 ">
        <h1 className="text-white text-xl font-bold text-center">
          <p className="text-white">
            © 2024
            <a
              href="/"
              className="text-white hover:opacity-80 font-semibold transition-opacity nav-link ml-2"
            >
              STOCK BUBBLES
            </a>
          </p>
        </h1>
      </div>
    </>
  );
};

export default Footer;
