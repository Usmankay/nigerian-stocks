import React, { useEffect, useMemo, useRef, useState } from "react";
import * as PIXI from "pixi.js";
import {
  createText,
  createText2,
  getScalingFactor,
  height,
  maxCircleSize,
  minCircleSize,
  speed,
  width,
} from "./pixiHelpers";
import { actualSampleData, bubbleContent } from "../Constant";

const PixiBubbles = () => {
  const [modalContent, setModalContent] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const pixiContainerRef = useRef(null);

  const scalingFactor = useMemo(() => {
    return getScalingFactor(actualSampleData);
  }, []);

  useEffect(() => {
    if (typeof PIXI === "undefined") {
      console.error(
        "PIXI is not defined. Please check if the Pixi.js library is loaded correctly."
      );
      return;
    }

    const app = new PIXI.Application({
      width: width,
      height: height,
      backgroundColor: "#222222",
    });
    // eslint-disable-next-line no-undef
    globalThis.__PIXI_APP__ = app;
    pixiContainerRef.current.appendChild(app.view);

    let selectedBubble = null;

    const getRandomColor = (percentage) => (percentage > 0 ? "blue" : "orange");

    const createGradientTexture = (colorStart, colorEnd, radius) => {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      canvas.width = 2 * radius;
      canvas.height = 2 * radius;

      const gradient = ctx.createRadialGradient(
        radius,
        radius,
        0,
        radius,
        radius,
        radius
      );
      gradient.addColorStop(0.5, colorStart);
      gradient.addColorStop(1, colorEnd);

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(radius, radius, radius, 0, Math.PI * 2);
      ctx.fill();

      return PIXI.Texture.from(canvas);
    };

    const createBubble = (x, y, bubbleData, color) => {
      const blueGradientTexture = createGradientTexture(
        "rgba(0, 0, 186, 0.2)",
        "rgba(0, 0, 186, 0.9)",
        bubbleData.radius
      );
      const orangeGradientTexture = createGradientTexture(
        "rgba(240, 122, 0, 0.2)",
        "rgba(240, 122, 0, 0.9)",
        bubbleData.radius
      );

      const bubble = new PIXI.Container();
      bubble.hitArea = new PIXI.Circle(
        bubbleData.radius,
        bubbleData.radius,
        bubbleData.radius
      );

      bubble.eventMode = "dynamic";
      // bubble.
      app.stage.addChild(bubble);
      const texture =
        color === "blue" ? blueGradientTexture : orangeGradientTexture;
      const gradientSprite = new PIXI.Sprite(texture);
      gradientSprite.anchor.set(0.5);
      gradientSprite.x = bubbleData.radius;
      gradientSprite.y = bubbleData.radius;
      bubble.addChild(gradientSprite);

      bubble.x = x;
      bubble.y = y;
      bubble.radius = bubbleData.radius;
      bubble.vx = Math.random() * speed * 2 - speed;
      bubble.vy = Math.random() * speed * 2 - speed;

      bubble.interactive = true;
      bubble.buttonMode = true;
      bubble.cursor = "pointer";

      // Add main text inside the bubble
      // const mainText = new PIXI.Text("BTC", {
      //   fontFamily: "Arial",
      //   fontSize: radius * 0.4,
      //   fill: 0xffffff,
      //   align: "center",
      // });
      // mainText.anchor.set(0.5);
      // mainText.x = radius;
      // mainText.y = radius - 1;
      const mainText = createText(bubbleData);
      bubble.addChild(mainText);

      // Add secondary text inside the bubble
      // const secondaryText = new PIXI.Text("+0.01%", {
      //   fontFamily: "Arial",
      //   fontSize: radius * 0.25,
      //   fill: 0xffffff,
      //   align: "center",
      // });
      // secondaryText.anchor.set(0.5);
      // secondaryText.x = radius;
      // secondaryText.y = radius * 1.45;
      // : radius === minCircleSize
      // ? radius + 15
      // : radius + 50;
      const secondaryText = createText2(bubbleData, bubbleContent);
      bubble.addChild(secondaryText);

      bubble.on("pointerdown", () => {
        if (selectedBubble) {
          selectedBubble.isHighlighted = false;
        }
        selectedBubble = bubble;
        selectedBubble.isHighlighted = true;
        showModal(
          `Bubble at (${Math.round(bubble.x)}, ${Math.round(
            bubble.y
          )}) with radius ${Math.round(bubble.radius)}`
        );
      });

      return bubble;
    };

    const showModal = (content) => {
      setModalContent(content);
      setIsModalOpen(true);
    };

    const checkCollision = (bubble1, bubble2) => {
      const dx = bubble1.x - bubble2.x;
      const dy = bubble1.y - bubble2.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      return distance < bubble1.radius + bubble2.radius;
    };

    const bubbles = [];
    for (let i = 0; i < actualSampleData.length; i++) {
      let x, y, radius, color, bubble;
      let isValid = false;
      while (!isValid) {
        radius = Math.abs(scalingFactor * actualSampleData[i]["volume"]);

        x = Math.random() * (width - radius * 2);
        y = Math.random() * (height - radius * 2);
        // vx = Math.random() * speed * 2 - speed;
        // vy = Math.random() * speed * 2 - speed;
        // x = Math.random() * app.screen.width;
        // y = Math.random() * app.screen.height;
        color = getRandomColor(actualSampleData[i]["performance"]);
        // radius = getScalingFactor(actualSampleData);
        radius =
          radius > maxCircleSize
            ? maxCircleSize
            : radius < minCircleSize
            ? minCircleSize
            : minCircleSize;
        actualSampleData[i]["radius"] = radius;
        bubble = createBubble(x, y, actualSampleData[i], color);
        isValid = true;
        for (const existingBubble of bubbles) {
          if (checkCollision(bubble, existingBubble)) {
            isValid = false;
            app.stage.removeChild(bubble);
            break;
          }
        }
      }
      bubbles.push(bubble);
    }

    const resolveCollision = (bubble1, bubble2) => {
      const dx = bubble1.x - bubble2.x;
      const dy = bubble1.y - bubble2.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      const overlap = 0.1 * (distance - bubble1.radius - bubble2.radius);

      bubble1.x -= (overlap * (bubble1.x - bubble2.x)) / distance;
      bubble1.y -= (overlap * (bubble1.y - bubble2.y)) / distance;

      bubble2.x += (overlap * (bubble1.x - bubble2.x)) / distance;
      bubble2.y += (overlap * (bubble1.y - bubble2.y)) / distance;

      const tempVx = bubble1.vx;
      const tempVy = bubble1.vy;
      bubble1.vx = bubble2.vx;
      bubble1.vy = bubble2.vy;
      bubble2.vx = tempVx;
      bubble2.vy = tempVy;
    };

    app.ticker?.add(() => {
      bubbles.forEach((bubble) => {
        bubble.x += bubble.vx;
        bubble.y += bubble.vy;

        if (bubble.x - bubble.radius < 0) {
          bubble.x = bubble.radius;
          bubble.vx *= -0.1;
        }
        if (bubble.x + bubble.radius > app.screen.width) {
          bubble.x = app.screen.width - bubble.radius;
          bubble.vx *= -0.1;
        }
        if (bubble.y - bubble.radius < 0) {
          bubble.y = bubble.radius;
          bubble.vy *= -0.1;
        }
        if (bubble.y + bubble.radius > app.screen.height) {
          bubble.y = app.screen.height - bubble.radius;
          bubble.vy *= -0.1;
        }

        bubbles.forEach((otherBubble) => {
          if (bubble !== otherBubble && checkCollision(bubble, otherBubble)) {
            resolveCollision(bubble, otherBubble);
          }
        });
      });
    });

    app.view.addEventListener("click", (event) => {
      const mouseX = event.clientX;
      const mouseY = event.clientY;

      bubbles.forEach((bubble) => {
        const dx = bubble.x - mouseX;
        const dy = bubble.y - mouseY;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const force = Math.max(0, 100 - distance);
        const angle = Math.atan2(dy, dx);
        bubble.vx += (Math.cos(angle) * force) / 100;
        bubble.vy += (Math.sin(angle) * force) / 100;
      });
    });

    window.addEventListener("resize", () => {
      app.renderer.resize(window.innerWidth, window.innerHeight);
    });

    return () => {
      app.destroy(true, true);
    };
  }, [scalingFactor]);

  return (
    <div>
      <div
        ref={pixiContainerRef}
        // className="fixed top-0 left-0 w-full h-full"
      ></div>
      {isModalOpen && (
        <div>
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={() => setIsModalOpen(false)}
          ></div>
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 bg-white border-2 border-gray-300 rounded-lg p-5 shadow-lg z-50">
            <h2 className="text-xl mb-4">Bubble Details</h2>
            <p id="modal-content">{modalContent}</p>
            <button
              className="bg-blue-500 text-white border-none py-2 px-4 rounded cursor-pointer mt-4 hover:bg-blue-700"
              onClick={() => setIsModalOpen(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PixiBubbles;
