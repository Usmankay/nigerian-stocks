import React, { useState } from "react";
import "./Bubble.css";
import Modal from "../Modal";
import AreaChart from "../Charts/AreaChart";
import Tabs from "../Tabs";

const FloatingBubble = ({ left, top, size, color, data }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <>
      <div
        className="p-[10px] rounded-full absolute"
        style={{ left: `${left}px`, top: `${top}px` }}
      >
        <div
          onClick={openModal}
          style={{ width: `${size}px`, height: `${size}px`, boxShadow: color }}
          className="bubble rounded-full"
        >
          <div className="data flex flex-col items-center gap-1">
            <img src={data.image} alt={data.name} />
            {data.size > 100 && (
              <span
                className={`${
                  data.dayChange.includes("+")
                    ? "text-green-500"
                    : "text-red-500"
                }`}
              >
                {data.dayChange}
              </span>
            )}
          </div>
        </div>
      </div>

      <Modal isOpen={isModalOpen} onClose={closeModal}>
        <div>
          <AreaChart />
          <Tabs />
        </div>
      </Modal>
    </>
  );
};

export default FloatingBubble;
