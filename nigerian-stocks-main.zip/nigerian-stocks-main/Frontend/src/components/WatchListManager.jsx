import { useState } from "react";
import { FaPlus } from "react-icons/fa6";
import { MdDelete } from "react-icons/md";
import { RiPencilFill } from "react-icons/ri";

const WatchlistManager = () => {
  const [watchlists, setWatchlists] = useState([{ id: 1, name: "" }]);

  const addInput = () => {
    setWatchlists([...watchlists, { id: Date.now(), name: "" }]);
  };

  const deleteInput = (id) => {
    if (watchlists.length === 1) return;

    setWatchlists(watchlists.filter((item) => item.id !== id));
  };

  const handleInputChange = (id, value) => {
    setWatchlists(
      watchlists.map((item) => {
        if (item.id === id) {
          return { ...item, name: value };
        }
        return item;
      })
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Watchlists</h3>
        <button
          type="button"
          onClick={addInput}
          className="text-xl font-medium p-2 text-white bg-[#585858] rounded-full"
        >
          <FaPlus />
        </button>
      </div>
      {watchlists.map(({ id, name }, index) => (
        <div key={id} className="flex items-center justify-between">
          <div className="group relative w-full">
            <div className="group-hover:text-blue-500 absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
              <RiPencilFill />
            </div>
            <input
              type="text"
              value={name}
              onChange={(e) => handleInputChange(id, e.target.value)}
              className="bg-transparent text-white border border-[#6c6b6b] text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5"
              placeholder={`Watchlist ${index + 1}`}
              required
            />
          </div>
          <button
            type="button"
            onClick={() => deleteInput(id)}
            className="text-xl ml-4  font-medium p-2 text-white bg-[#585858] rounded-full"
          >
            <MdDelete />
          </button>
        </div>
      ))}
    </div>
  );
};

export default WatchlistManager;
