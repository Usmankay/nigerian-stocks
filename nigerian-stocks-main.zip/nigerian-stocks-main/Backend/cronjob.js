const cron = require("node-cron");
const { getData } = require("./App/services/cronFunctions");

function cleanUpMemory() {
  // Force garbage collection if available
  if (global.gc) {
    global.gc(); // Trigger garbage collection to release unused memory
    console.log("Memory cleaned up.");
  } else {
    console.log(
      "Run Node.js with --expose-gc flag to enable manual garbage collection."
    );
  }
}

cron.schedule("*/15 * * * *", () => {
  console.log("Running cron job...");
  cleanUpMemory();
  getData();
});
