"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class StockHistory extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  StockHistory.init(
    {
      symbol: DataTypes.STRING,
      name: DataTypes.STRING,
      tradeDate: DataTypes.STRING,
      close: DataTypes.FLOAT,
      volume: DataTypes.BIGINT,
      onSettleValue: DataTypes.FLOAT,
      numTrades: DataTypes.BIGINT,
      open: DataTypes.FLOAT,
      low: DataTypes.FLOAT,
      high: DataTypes.FLOAT,
      isoIsin: DataTypes.STRING,
      nominalValue: DataTypes.FLOAT,
      marketCap: DataTypes.FLOAT,
      eps: DataTypes.FLOAT,
      peRatio: DataTypes.FLOAT,
      amount: DataTypes.FLOAT,
      sector: DataTypes.STRING,
      // New fields
      asset: { type: DataTypes.STRING, allowNull: true },
      change: { type: DataTypes.INTEGER, allowNull: true },
      csi: { type: DataTypes.STRING, allowNull: true },
      last: { type: DataTypes.INTEGER, allowNull: true },
      perChange: { type: DataTypes.INTEGER, allowNull: true },
      timestamp: { type: DataTypes.STRING, allowNull: true },
      value: { type: DataTypes.INTEGER, allowNull: true },
      dailyPerformance: { type: DataTypes.FLOAT, allowNull: true },
      weeklyPerformance: { type: DataTypes.FLOAT, allowNull: true },
      monthlyPerformance: { type: DataTypes.FLOAT, allowNull: true },
      yearlyPerformance: { type: DataTypes.FLOAT, allowNull: true },
      yearToDatePerformance: { type: DataTypes.FLOAT, allowNull: true },
      rank: { type: DataTypes.INTEGER, allowNull: true },
    },
    {
      sequelize,
      modelName: "StockHistory",
    }
  );

  return StockHistory;
};
