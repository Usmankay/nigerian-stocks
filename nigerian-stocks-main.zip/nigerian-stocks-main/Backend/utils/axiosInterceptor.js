const axios = require("axios");
const { get } = require("lodash");
require("dotenv").config();

const axiosInstance = axios.create();
axiosInstance.defaults.baseURL = process.env.NGX_BASE_URL;

// Request Interceptor. All Request pass from here
axiosInstance.interceptors.request.use(
  (axiosConfig) => {
    if (axiosConfig.rawRequest) {
      // header for file_upload, video/audio will handle here i.e raw requests
    } else {
      axiosConfig.headers["Content-Type"] = "application/json";
    }
    return axiosConfig;
  },
  (error) => {
    return Promise.reject(error);
  }
);

/*
  Response Interceptor
  Responsibilities:
  1- If api sends 401 token then send user to login page
*/
axiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  function (error) {
    if (get(error, "response.status", "") === 401) {
      // Add logic to redirect user to login page
    } else {
      return Promise.reject(error);
    }
  }
);

module.exports = axiosInstance;
