var WebSocket = require("ws");

var wss;

function initializeWebSocketServer(server) {
  wss = new WebSocket.Server({ server: server });

  wss.on("connection", function (ws) {
    console.log("New client connected");

    ws.on("message", function (message) {
      console.log("Received message: " + message);
    });

    ws.on("close", function () {
      console.log("Client disconnected");
    });
  });

  return wss;
}

function broadcast(data) {
  wss.clients.forEach(function (client) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  });
}

module.exports = {
  initializeWebSocketServer: initializeWebSocketServer,
  broadcast: broadcast,
};
