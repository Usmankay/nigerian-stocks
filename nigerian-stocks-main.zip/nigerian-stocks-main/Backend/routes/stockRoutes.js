const express = require("express");
const {
  parseCSVFile,
  testCron,
  listStocks,
  getStocksData,
} = require("../App/controllers/StockController");
const {
  ListFilterValidators,
} = require("../App/validators/ListFilterValidator");

const router = express.Router();

router.get("/parse-csv", parseCSVFile);
router.get("/test-cron", testCron);
router.post("/list", [ListFilterValidators()], listStocks);
router.get("/sectors", getStocksData);

module.exports = router;
