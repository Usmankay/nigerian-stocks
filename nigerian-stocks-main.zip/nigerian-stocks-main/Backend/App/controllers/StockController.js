const {
  parseCSV,
  testCronJob,
  listStocks,
  getSectorStockCounts,
} = require("../services/StockServices");
const { validationResult } = require("express-validator");
const { errorHandlerService } = require("../services/responseHandlerServics");

const parseCSVFile = async (req, res) => {
  try {
    const results = await parseCSV();
    res.json(results);
  } catch (error) {
    res.status(500).send(error.message);
  }
};

const testCron = async (req, res) => {
  try {
    const data = await testCronJob();
    if (data) {
      res.status(200).json(data);
    } else {
      res.status(400).send("No data available");
    }
  } catch (error) {
    res.status(500).send(error.message);
  }
};

const listStocksData = async (req, res) => {
  try {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res
        .status(200)
        .json(errorHandlerService("Validation Error", errors.array()));
    }
    const { page: currentPage, pageSize, filters } = req.body;
    const data = await listStocks(currentPage ?? 1, pageSize ?? 100, filters);
    if (data) {
      res.status(200).json(data);
    } else {
      res.status(200).send("No data available");
    }
  } catch (error) {
    res.status(500).send(error.message);
  }
};

const getStocksData = async (req, res) => {
  try {
    const data = await getSectorStockCounts();
    if (data) {
      res.status(200).json(data);
    } else {
      res.status(200).send("No data available");
    }
  } catch (error) {
    res.status(500).send(error.message);
  }
};

module.exports = {
  parseCSVFile: parseCSVFile,
  testCron: testCron,
  listStocks: listStocksData,
  getStocksData,
};
