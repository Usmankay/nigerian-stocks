const axios = require("../../utils/axiosInterceptor");
const errorHandlerService =
  require("./responseHandlerServics").errorHandlerService;
const dotenv = require("dotenv");
const { StockHistory } = require("../../models");
const { successHandler } = require("./responseHandlerServics");
const { Op } = require("sequelize");
const dayjs = require("dayjs");
const isBetween = require("dayjs/plugin/isBetween"); // Add necessary plugins
dayjs.extend(isBetween);

dotenv.config();

const token = process.env.NGX_TOKEN;

const getData = async function () {
  try {
    const { data: responseData } = await axios.get(
      "/price/pricesDL.json?_t=" + token
    );
    if (responseData.length) {
      const returendData = await Promise.all(
        responseData
          .sort((a, b) => b.Volume - a.Volume)
          .map(async (element, index) => {
            const dateData = dayjs(element.TradeDate).format(
              "YYYY-MM-DDTHH:mm:ss"
            );

            console.log("===========Date=============");
            console.log(dateData, element.TradeDate);
            console.log("====================================");

            const daily =
              ((element?.Close ? parseFloat(element?.Close) : 0) -
                (element?.Open ? parseFloat(element?.Open) : 0)) /
              (element?.Open ? parseFloat(element?.Open) : 0);

            const elementData = {
              symbol: element.Symbol.split(" ")[0],
              csi: element.CSI,
              last: element.Last,
              change: element.Change,
              perChange: element.PerChange,
              asset: element.Asset,
              tradeDate: dateData,
              timestamp: element.Timestamp,
              open: element.Open,
              high: element.High,
              low: element.Low,
              volume: element.Volume,
              value: element.Value,
              close: element.Close,
              dailyPerformance: daily * 100,
              weeklyPerformance: 0,
              monthlyPerformance: 0,
              yearlyPerformance: 0,
              yearToDatePerformance: 0,
              rank: index + 1,
            };

            const stockName = await StockHistory.findOne({
              where: {
                symbol: elementData.symbol,
              },
            });
            if (stockName) {
              elementData.name = stockName.name;
              elementData.isoIsin = stockName.isoIsin;
              elementData.sector = stockName.sector;
            }

            const existingData = await StockHistory.findOne({
              where: {
                tradeDate: elementData.tradeDate,
                symbol: elementData.symbol,
              },
            });

            const yearData = await StockHistory.findAll({
              where: {
                symbol: elementData.symbol,
                tradeDate: {
                  [Op.between]: [
                    `${dayjs(dateData)
                      .subtract(365, "day")
                      .format("YYYY-MM-DDTHH:mm:ss")}`,
                    dateData,
                  ],
                },
              },
              order: [["tradeDate", "ASC"]],
            });

            const monthly = await StockHistory.findAll({
              where: {
                symbol: elementData.symbol,
                tradeDate: {
                  [Op.between]: [
                    `${dayjs(dateData)
                      .subtract(30, "day")
                      .format("YYYY-MM-DDTHH:mm:ss")}`,
                    dateData,
                  ],
                },
              },
              order: [["tradeDate", "ASC"]],
            });

            const weeklyData = await StockHistory.findAll({
              where: {
                symbol: elementData.symbol,
                tradeDate: {
                  [Op.between]: [
                    `${dayjs(dateData)
                      .subtract(7, "day")
                      .format("YYYY-MM-DDTHH:mm:ss")}`,
                    dateData,
                  ],
                },
              },
              order: [["tradeDate", "ASC"]],
            });

            const yearToDate = await StockHistory.findAll({
              where: {
                symbol: elementData.symbol,
                tradeDate: {
                  [Op.between]: [
                    `${dayjs(dateData)
                      .startOf("year")
                      .format("YYYY-MM-DDTHH:mm:ss")}`,
                    dateData,
                  ],
                },
              },
              order: [["tradeDate", "ASC"]],
            });

            if (yearToDate) {
              const year =
                ((element?.Close ? parseFloat(element?.Close) : 0) -
                  (yearToDate[0]?.open ? parseFloat(yearToDate[0]?.open) : 0)) /
                (yearToDate[0]?.open ? parseFloat(yearToDate[0]?.open) : 0);
              elementData.yearToDatePerformance =
                parseFloat(year !== Infinity ? year : 0) * 100;
            }

            if (yearData) {
              const year =
                ((element?.Close ? parseFloat(element?.Close) : 0) -
                  (yearData[0]?.open ? parseFloat(yearData[0]?.open) : 0)) /
                (yearData[0]?.open ? parseFloat(yearData[0]?.open) : 0);
              elementData.yearlyPerformance =
                parseFloat(year !== Infinity ? year : 0) * 100;
            }

            if (monthly) {
              const month =
                ((element?.Close ? parseFloat(element?.Close) : 0) -
                  (monthly[0]?.open ? parseFloat(monthly[0]?.open) : 0)) /
                (monthly[0]?.open ? parseFloat(monthly[0]?.open) : 0);
              elementData.monthlyPerformance =
                parseFloat(month !== Infinity ? month : 0) * 100;
            }

            if (weeklyData) {
              const week =
                ((element?.Close ? parseFloat(element?.Close) : 0) -
                  (weeklyData[0]?.open ? parseFloat(weeklyData[0]?.open) : 0)) /
                (weeklyData[0]?.open ? parseFloat(weeklyData[0]?.open) : 0);
              elementData.weeklyPerformance =
                parseFloat(week !== Infinity ? week : 0) * 100;
            }

            if (existingData) {
              await existingData.update(elementData);
            } else {
              await StockHistory.create(elementData);
            }
            return elementData;
          })
      );
      console.log("----------------done---------------------");

      return successHandler("Added Success Fully", returendData);
    }
    return errorHandlerService("No Data Found");
  } catch (error) {
    console.error("Error Fetching data:", error);
    return errorHandlerService("Error Fetching data", error);
  }
};

module.exports = {
  getData: getData,
};
