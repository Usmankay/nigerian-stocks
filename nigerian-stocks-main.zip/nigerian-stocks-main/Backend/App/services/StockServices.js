const fs = require("fs");
const csv = require("csv-parser");
const { StockHistory } = require("../../models");
const cronFunctions = require("./cronFunctions.js");
const path = require("path");
const { Op, fn, col, literal, where } = require("sequelize");

const parseCSV = () => {
  const filePath = path.join(__dirname, "../../", "history.csv");

  console.log("====================================");
  console.log(filePath);
  console.log("====================================");

  return new Promise((resolve, reject) => {
    let results = [];
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (data) => {
        let transformedData = {};
        for (const key in data) {
          const camelCaseKey = key
            .split("_")
            .map((word, index) =>
              index === 0
                ? word.toLowerCase()
                : word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
            )
            .join("");
          transformedData[camelCaseKey] = data[key].trim();

          switch (camelCaseKey) {
            case "tradeDate":
              transformedData[camelCaseKey] = `${
                new Date(data[key]).toISOString().split("T")[0]
              }T00:00:00`;
              break;
            case "close":
            case "onSettleValue":
            case "open":
            case "low":
            case "high":
            case "nominalValue":
            case "marketCap":
            case "eps":
            case "peRatio":
            case "amount":
              transformedData[camelCaseKey] =
                data[key] === "NULL" ? null : parseFloat(data[key]);
              break;
            case "volume":
            case "numTrades":
              transformedData[camelCaseKey] =
                data[key] === "NULL" ? null : parseInt(data[key], 10);
              break;
            default:
              transformedData[camelCaseKey] = data[key];
              break;
          }
        }
        results.push(transformedData);
      })
      .on("end", async () => {
        try {
          await StockHistory.bulkCreate(results, { validate: true });
          resolve(results);
        } catch (error) {
          reject(error);
        }
      })
      .on("error", (err) => {
        reject(err);
      });
  });
};

const testCronJob = async () => {
  try {
    return await cronFunctions.getData();
  } catch (error) {
    throw new Error(error.message);
  }
};

const calculatePerformance = (data) => {
  if (data.length > 1) {
    const firstClose = data[0].close;
    const lastClose = data[data.length - 1].close;
    return Math.round(((firstClose - lastClose) / lastClose) * 100 * 100) / 100;
  }
  return null;
};

const formatDate = (date) => {
  return `${date.getFullYear()}-${
    date.getMonth() + 1 < 10 ? `0${date.getMonth() + 1}` : date.getMonth() + 1
  }-${date.getDate() < 10 ? "0" : ""}${date.getDate()}T00:00:00`;
};

const getStartDateForPeriod = (period, referenceDate = new Date()) => {
  let startDate = new Date(referenceDate);

  switch (period) {
    case "last8days":
      startDate.setDate(startDate.getDate() - 8);
      break;
    case "thisMonth":
      startDate = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
      break;
    case "thisYear":
      startDate = new Date(
        startDate.getFullYear() - 1,
        startDate.getMonth(),
        startDate.getDay()
      );
      break;
    default:
      startDate = null;
  }

  return startDate ? formatDate(startDate) : null;
};

const getDataForSpecificPeriod = async (symbol, period) => {
  const startDate = getStartDateForPeriod(
    period,
    new Date("2024-07-24T00:00:00")
  );
  const endDate = formatDate(new Date("2024-07-24T00:00:00"));

  if (!startDate) return null;

  const periodData = await StockHistory.findAll({
    where: {
      symbol,
      tradeDate: {
        [Op.between]: [startDate, endDate],
      },
    },
    order: [["tradeDate", "DESC"]],
  });

  const performance = calculatePerformance(periodData);

  return { performance, periodData };
};

const listStocks = async (
  page = 1,
  limit = 100,
  filters = {},
  order = "DESC"
) => {
  // const offset = (page - 1) * limit;
  const whereData = {};
  if (filters.startDate && filters.endDate) {
    whereData.tradeDate = {
      [Op.between]: [
        filters.startDate ?? "2023-02-01T00:00:00",
        filters.endDate ?? "2023-02-02T00:00:00",
      ],
    };
  }
  // const attributes = [...Object.keys(StockHistory.rawAttributes)];
  let sort = [["volume", order]];

  // Apply filters
  if (filters.symbol) whereData.symbol = filters.symbol;
  if (filters.search) {
    whereData.symbol = {
      [Op.like]: `%${filters.search}%`,
    };
  }
  if (filters.asset && filters.asset !== "ALL") {
    whereData.asset = filters.asset;
  }
  if (filters.sector) whereData.sector = filters.sector;

  // if (filters.timeFrame) {
  //   const startDate = getStartDateForPeriod(filters.timeFrame);
  //   if (startDate) {
  //     whereData.tradeDate = {
  //       [Op.between]: [startDate, formatDate(new Date())],
  //     };
  //   }
  // }

  // if (filters.priceRange) {
  //   whereData.open = {
  //     [Op.between]: [filters.priceRange.from, filters.priceRange.to],
  //   };
  // }

  // // Calculate performance
  // const performanceCalculation = literal(
  //   "ROUND(((COALESCE(close, 0) - COALESCE(open, 0)) / COALESCE(open, 1)) * 100, 2)"
  // );
  // attributes.push([performanceCalculation, "performance"]);
  // // attributes.push([
  // //   literal(`
  // //     (SELECT JSON_ARRAYAGG(JSON_OBJECT(
  // //       'id', sh2.id,
  // //       'symbol', sh2.symbol,
  // //       'tradeDate', sh2.tradeDate,
  // //       'close', sh2.close,
  // //       'volume', sh2.volume,
  // //       'onSettleValue', sh2.onSettleValue,
  // //       'numTrades', sh2.numTrades,
  // //       'open', sh2.open,
  // //       'low', sh2.low,
  // //       'high', sh2.high,
  // //       'isoIsin', sh2.isoIsin,
  // //       'nominalValue', sh2.nominalValue,
  // //       'marketCap', sh2.marketCap,
  // //       'eps', sh2.eps,
  // //       'peRatio', sh2.peRatio,
  // //       'amount', sh2.amount,
  // //       'sector', sh2.sector,
  // //       'asset', sh2.asset,
  // //       'change', sh2.change,
  // //       'csi', sh2.csi,
  // //       'last', sh2.last,
  // //       'perChange', sh2.perChange,
  // //       'timestamp', sh2.timestamp,
  // //       'value', sh2.value
  // //     ))
  // //     FROM StockHistories sh2
  // //     WHERE sh2.symbol = StockHistory.symbol
  // //       AND sh2.tradeDate BETWEEN '2023-01-01T00:00:00' AND '2024-05-30T00:00:00')
  // //   `),
  // //   "yearData",
  // // ]);

  // if (filters.performance) {
  //   if (filters.performance.field === "value") {
  //     attributes[attributes.length - 1] = [
  //       literal("ROUND(COALESCE(close, 0) - COALESCE(open, 0), 2)"),
  //       "performance",
  //     ];
  //   }

  //   sort = [
  //     ["performance", filters.performance.value === "gainers" ? "DESC" : "ASC"],
  //   ];

  //   if (filters.performance.value === "active") {
  //     sort.push(["numTrades", "DESC"]);
  //   }
  // }

  // // Additional filters
  // if (filters.volume) {
  //   whereData.tradeDate = {
  //     [Op.between]: ["2024-07-24T00:00:00", "2024-07-24T00:00:00"],
  //   };
  //   sort = [
  //     ["tradeDate", "DESC"],
  //     ["volume", "DESC"],
  //   ];
  // }

  // if (filters.marketCap) {
  //   whereData.tradeDate = {
  //     [Op.between]: ["2024-06-27T00:00:00", "2024-06-28T00:00:00"],
  //   };
  //   sort = [
  //     ["tradeDate", "DESC"],
  //     ["marketCap", "DESC"],
  //   ];
  // }

  // Optimize query
  const stockHistory = await StockHistory.findAll({
    where: whereData,
    // attributes,
    order: sort,
    // limit,
    // offset,
    raw: true,
  });

  // Fetch period data in parallel
  // const fetchPeriodData = async (symbol) => {
  //   const thisYear = await getDataForSpecificPeriod(symbol, "thisYear");
  //   return {
  //     symbol,
  //     yearData: thisYear.periodData,
  //   };
  // };

  // Fetch period data for all rows in parallel
  // const periodDataPromises = stockHistory.map((stock) =>
  //   fetchPeriodData(stock.symbol)
  // );

  // const periodDataResults = await Promise.all(periodDataPromises);

  // Combine data with period data
  // const dataWithPeriods = stockHistory.map((stock) => {
  //   const periodData = periodDataResults.find(
  //     (pd) => pd.symbol === stock.symbol
  //   );
  //   return {
  //     ...stock,
  //     yearData: periodData ? periodData.yearData : null,
  //   };
  // });

  return {
    // page,
    // pageSize: limit,
    // totalPages: Math.ceil(stockHistory.count / limit),
    // totalCount: stockHistory.count,
    data: stockHistory,
  };
};

const getSectorStockCounts = async () => {
  try {
    // Query to get all unique sectors and count of unique stocks per sector
    const sectorCounts = await StockHistory.findAll({
      attributes: [
        [fn("COALESCE", col("sector"), literal("'Unknown'")), "sector"],
        [fn("COUNT", fn("DISTINCT", col("symbol"))), "count"], // Count of distinct symbols per sector
      ],
      group: ["sector"], // Group by sector to get counts
      order: [[fn("COUNT", fn("DISTINCT", col("symbol"))), "DESC"]], // Optional: order by count descending
    });

    // Aggregate the total count of unique stocks across all sectors
    const totalCount = await StockHistory.count({
      distinct: true,
      col: "symbol",
    });

    // Map the result to the desired format and add "All" entry
    const result = sectorCounts.map((sectorObj) => ({
      name: sectorObj.getDataValue("sector"),
      count: sectorObj.getDataValue("count"),
    }));

    // Add the "All" entry to include the total count
    result.unshift({ name: "All", count: totalCount });

    return result;
  } catch (error) {
    console.error("Error fetching sector stock counts:", error);
    throw new Error(error.message);
  }
};

module.exports = {
  parseCSV,
  testCronJob,
  listStocks,
  getSectorStockCounts,
};
