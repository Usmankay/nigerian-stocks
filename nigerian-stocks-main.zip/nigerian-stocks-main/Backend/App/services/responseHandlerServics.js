const successHandler = (message, data) => {
  return { status: true, message, data };
};

const errorHandlerService = (message, errors) => {
  if (errors) {
    return { status: false, message, errors };
  }
  return { status: false, message };
};

module.exports = { successHandler, errorHandlerService };
