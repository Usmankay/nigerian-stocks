const { formatInTimeZone } = require("date-fns-tz");

const getZoneTime = (dateTime, zone) => {
  const value = dateTime; // Replace with your date value
  const date = new Date(value);
  const timeZone = "America/New_York"; // GMT-7

  const zonedDate = formatInTimeZone(date, timeZone, "yyyy-MM-dd HH:mm:ss zzz");
  // const formattedDate = format(zonedDate, "yyyy-MM-dd");
  return zonedDate;
};

module.exports = {
  getZoneTime,
};
