// validators/userValidator.js
const { body } = require("express-validator");

// Define enums
// const timeFrameValues = ["daily", "weekly", "monthly", "yearly"];
// const marketCapValues = ["small", "mid", "large"];
// const performanceValues = [
//   // for percentage
//   { value: "gainers", field: "percentage" },
//   { value: "losers", field: "percentage" },
//   { value: "active", field: "percentage" },
//   // for value
//   { value: "gainers", field: "value" },
//   { value: "losers", field: "value" },
//   { value: "active", field: "value" },
// ];
// const volumeValues = ["low", "medium", "high"];
// const dividendValues = ["yes", "no"];

// Custom fields array
const customFields = [
  {
    field: "startDate",
    values: null,
    message: "Invalid timeFrame value.",
  },
  {
    field: "marketCap",
    values: null,
    message: "Invalid marketCap value.",
  },
  {
    field: "sector",
    values: null,
    message: "Invalid sector value.",
  },
  {
    field: "symbol",
    values: null,
    message: "Invalid symbol value.",
  },
  {
    field: "endDate",
    values: null,
    message: "Invalid performance value.",
  },
  {
    field: "priceRange",
    values: null,
    message: "Invalid priceRange value.",
  },
  {
    field: "search",
    values: null,
    message: "Invalid priceRange value.",
  },
  {
    field: "volume",
    values: null,
    message: "Invalid volume value.",
  },
  // {
  //   field: "dividend",
  //   values: dividendValues,
  //   message: "Invalid dividend value.",
  // },
];

const ListFilterValidators = () => {
  return [
    body("page").optional().isNumeric().withMessage("Page must be a number."),
    body("pageSize")
      .optional()
      .isNumeric()
      .withMessage("Page size must be a number."),
    body("filters")
      .optional()
      .isObject({
        strict: true,
      })
      .custom((value) => {
        if (value) {
          // Validate each custom field
          if (
            customFields.some((data) => Object.keys(value).includes(data.field))
          ) {
            customFields.forEach(({ field, values, message }) => {
              if (field === "performance" && value?.performance) {
                if (
                  !values.some(
                    (data) =>
                      data.value === value[field]?.value &&
                      data.field === value[field]?.field
                  )
                ) {
                  throw new Error(`${message} Field: ${field}`);
                }
              } else if (values) {
                if (value[field] && !values.includes(value[field])) {
                  throw new Error(`${message} Field: ${field}`);
                }
              }
            });
          }
        }
        return true;
      })
      .withMessage("Invalid filter object."),
  ];
};

module.exports = {
  ListFilterValidators,
};
