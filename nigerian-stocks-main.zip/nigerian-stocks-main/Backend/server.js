var express = require("express");
var bodyParser = require("body-parser");
var http = require("http");
var dotenv = require("dotenv");
const cors = require("cors");

// Importing individual functions from modules
const { initializeWebSocketServer } = require("./utils/Socket");
const stockRoutes = require("./routes/stockRoutes");

dotenv.config();

var app = express();
var port = process.env.PORT || 3000;
var server = http.createServer(app);

app.use(
  cors({
    origin: "*",
  })
);

initializeWebSocketServer(server);

app.use(bodyParser.json());

app.use("/api/stocks", stockRoutes);

app.get("/", function (req, res) {
  res.json({ message: "Welcome to Stock Bubbles API Center." });
});

server.listen(port, function () {
  console.log("Server running at http://localhost:" + port + "/");
});
