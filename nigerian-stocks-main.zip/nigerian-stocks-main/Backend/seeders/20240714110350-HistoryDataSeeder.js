"use strict";

const fs = require("fs");
const csv = require("csv-parser");
const { StockHistory } = require("../models");
const path = require("path");
const { getZoneTime } = require("../App/helpers/timeStampHelpers");

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    try {
      const filePath = path.join(__dirname, "..", "history.csv"); // Adjust the path to your CSV file
      const results = [];

      return new Promise((resolve, reject) => {
        fs.createReadStream(filePath)
          .pipe(csv())
          .on("data", (data) => {
            const transformedData = {};
            for (const key in data) {
              const camelCaseKey = key
                .split("_")
                .map((word, index) => {
                  if (index === 0) {
                    return word.toLowerCase();
                  }
                  return (
                    word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
                  );
                })
                .join("");
              transformedData[camelCaseKey] = data[key];
              let value = data[key].trim(); // Trim whitespace

              // Convert values to their respective data types
              switch (camelCaseKey) {
                case "tradeDate":
                  const date = new Date(value);
                  const month = date.getMonth();
                  const day = date.getDate();
                  const dateData = `${date.getFullYear()}-${
                    month + 1 < 10 ? `0${month + 1}` : month + 1
                  }-${day < 10 ? "0" : ""}${day}T00:00:00`;
                  transformedData[camelCaseKey] = dateData; // Assuming date format is correct
                  break;
                case "close":
                case "onSettleValue":
                case "open":
                case "low":
                case "high":
                case "nominalValue":
                case "marketCap":
                case "eps":
                case "peRatio":
                case "amount":
                  transformedData[camelCaseKey] =
                    value === "NULL" ? null : parseFloat(value);
                  break;
                case "volume":
                case "numTrades":
                  transformedData[camelCaseKey] =
                    value === "NULL" ? null : parseInt(value, 10);
                  break;
                default:
                  transformedData[camelCaseKey] = value;
                  break;
              }
            }
            results.push(transformedData);
          })
          .on("end", async () => {
            try {
              await StockHistory.bulkCreate(results, {
                validate: true,
              });
              resolve();
            } catch (error) {
              reject(error);
            }
          })
          .on("error", reject);
      });
    } catch (error) {
      console.error("Error seeding data:", error);
      throw error;
    }
  },

  async down(queryInterface, Sequelize) {},
};
