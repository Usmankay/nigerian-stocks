"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn("StockHistories", "dailyPerformance", {
      type: Sequelize.FLOAT,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "weeklyPerformance", {
      type: Sequelize.FLOAT,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "monthlyPerformance", {
      type: Sequelize.FLOAT,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "yearlyPerformance", {
      type: Sequelize.FLOAT,
      allowNull: true,
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn("StockHistories", "dailyPerformance");
    await queryInterface.removeColumn("StockHistories", "weeklyPerformance");
    await queryInterface.removeColumn("StockHistories", "monthlyPerformance");
    await queryInterface.removeColumn("StockHistories", "yearlyPerformance");
  },
};
