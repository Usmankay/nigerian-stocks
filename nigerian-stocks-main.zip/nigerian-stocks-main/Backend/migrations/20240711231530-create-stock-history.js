"use strict";
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("StockHistories", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      symbol: {
        type: Sequelize.STRING,
      },
      name: {
        type: Sequelize.STRING,
      },
      tradeDate: {
        type: Sequelize.STRING,
      },
      close: {
        type: Sequelize.FLOAT,
      },
      volume: {
        type: Sequelize.BIGINT,
      },
      onSettleValue: {
        type: Sequelize.FLOAT,
      },
      numTrades: {
        type: Sequelize.BIGINT,
      },
      open: {
        type: Sequelize.FLOAT,
      },
      low: {
        type: Sequelize.FLOAT,
      },
      high: {
        type: Sequelize.FLOAT,
      },
      isoIsin: {
        type: Sequelize.STRING,
      },
      nominalValue: {
        type: Sequelize.FLOAT,
      },
      marketCap: {
        type: Sequelize.FLOAT,
      },
      eps: {
        type: Sequelize.FLOAT,
      },
      peRatio: {
        type: Sequelize.FLOAT,
      },
      amount: {
        type: Sequelize.FLOAT,
      },
      sector: {
        type: Sequelize.STRING,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("StockHistories");
  },
};
