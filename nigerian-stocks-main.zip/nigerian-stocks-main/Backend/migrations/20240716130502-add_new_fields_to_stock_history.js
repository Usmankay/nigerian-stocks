"use strict";

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addColumn("StockHistories", "asset", {
      type: Sequelize.STRING,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "change", {
      type: Sequelize.INTEGER,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "csi", {
      type: Sequelize.STRING,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "last", {
      type: Sequelize.INTEGER,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "perChange", {
      type: Sequelize.INTEGER,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "timestamp", {
      type: Sequelize.STRING,
      allowNull: true,
    });
    await queryInterface.addColumn("StockHistories", "value", {
      type: Sequelize.INTEGER,
      allowNull: true,
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn("StockHistories", "asset");
    await queryInterface.removeColumn("StockHistories", "change");
    await queryInterface.removeColumn("StockHistories", "csi");
    await queryInterface.removeColumn("StockHistories", "last");
    await queryInterface.removeColumn("StockHistories", "perChange");
    await queryInterface.removeColumn("StockHistories", "timestamp");
    await queryInterface.removeColumn("StockHistories", "value");
  },
};
