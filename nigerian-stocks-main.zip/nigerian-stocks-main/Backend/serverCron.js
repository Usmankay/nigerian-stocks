var express = require("express");
var bodyParser = require("body-parser");
var http = require("http");
var dotenv = require("dotenv");

require("./cronjob");

dotenv.config();

var app = express();
var port = process.env.CRON_PORT || 3001;
var server = http.createServer(app);

app.get("/", function (req, res) {
  res.json({ message: "Welcome to Stock Bubbles CRON Center." });
});

server.listen(port, function () {
  console.log("Server running at http://localhost:" + port + "/");
});
